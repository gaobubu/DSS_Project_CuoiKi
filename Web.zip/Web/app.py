import pandas as pd
import numpy as np
from flask import Flask, render_template, jsonify
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

def load_and_process_data(file_path):
    try:
        # Đọc tệp CSV
        data = pd.read_csv(file_path, delimiter=";")
        data.columns = data.columns.str.strip()  # Dọn dẹp tên cột
        data["Order_Date"] = pd.to_datetime(data["Order_Date"], dayfirst=True)
        
        # Tính doanh thu (Số lượng * Giá)
        data["Price_Each"] = data["Price_Each"].str.replace(",", "").astype(float)
        data["Sales"] = data["Quantity_Ordered"] * data["Price_Each"]
        
        # Tính tổng doanh thu theo tháng
        monthly_sales = data.set_index("Order_Date").resample("M")["Sales"].count().reset_index()
        return monthly_sales
    except Exception as e:
        raise ValueError(f"Lỗi khi tải và xử lý dữ liệu: {e}")

def run_model(model, X, y, future_days):
    model.fit(X, y)
    future_X = np.array(future_days).reshape(-1, 1)
    y_pred = model.predict(future_X)
    mae = mean_absolute_error(y, model.predict(X))
    mse = mean_squared_error(y, model.predict(X))
    return y_pred, round(mae, 2), round(mse, 2)

@app.route('/')
def index():
    try:
        data_path = "D:/DSS/Project/data.csv"
        monthly_sales = load_and_process_data(data_path)
        
        # Chuẩn bị dữ liệu để huấn luyện mô hình
        X = np.array((monthly_sales["Order_Date"] - monthly_sales["Order_Date"].min()).dt.days).reshape(-1, 1)
        y = monthly_sales["Sales"].values
        
        # Ngày dự báo trong tương lai
        future_dates = pd.date_range(start="2020-01-01", periods=12, freq='M')
        future_days = [(date - monthly_sales["Order_Date"].min()).days for date in future_dates]
        
        # Mô hình Hồi quy tuyến tính
        linear_model = LinearRegression()
        y_pred_linear, mae_linear, mse_linear = run_model(linear_model, X, y, future_days)
        
        # Mô hình Cây quyết định
        tree_model = DecisionTreeRegressor(random_state=42)
        y_pred_tree, mae_tree, mse_tree = run_model(tree_model, X, y, future_days)

        # Lưu kết quả dự báo vào các tệp CSV
        linear_df = pd.DataFrame({"Month": future_dates.month, "Linear_Prediction": y_pred_linear})
        tree_df = pd.DataFrame({"Month": future_dates.month, "Tree_Prediction": y_pred_tree})
        
        linear_df.to_csv('linear_predictions.csv', index=False)
        tree_df.to_csv('tree_predictions.csv', index=False)

        # Tính độ chính xác
        mean_actual = y.mean()
        accuracy_linear = round((1 - mae_linear / mean_actual) * 100, 2)
        accuracy_tree = round((1 - mae_tree / mean_actual) * 100, 2)

        # Xác định mô hình tốt hơn
        better_model = "Hồi quy tuyến tính" if mae_linear < mae_tree and mse_linear < mse_tree else "Cây quyết định" if mae_tree < mae_linear and mse_tree < mse_linear else "Cả hai mô hình hoạt động tương tự"

        # Định dạng kết quả dự báo doanh thu (làm tròn và thêm đơn vị "USD")
        y_pred_linear_usd = [f"${round(pred, 2):,.2f}" for pred in y_pred_linear]
        y_pred_tree_usd = [f"${round(pred, 2):,.2f}" for pred in y_pred_tree]

        # Định dạng dữ liệu doanh thu thực tế với nhãn tháng
        sales_usd = [f"Tháng {i+1}: ${round(sale, 2):,.2f} USD" for i, sale in enumerate(monthly_sales["Sales"])]

        # Tạo danh sách dự báo theo tháng cho Hồi quy tuyến tính và Cây quyết định
        linear_results = [(i+1, result) for i, result in enumerate(y_pred_linear_usd)]
        tree_results = [(i+1, result) for i, result in enumerate(y_pred_tree_usd)]

        # Vẽ biểu đồ kết quả
        plt.figure(figsize=(14, 7))
        plt.plot(monthly_sales["Order_Date"], y, marker='o', color="black", label="Doanh thu thực tế 2019", linewidth=2)
        plt.plot(future_dates, y_pred_linear, color="blue", marker="x", label="Dự báo - Hồi quy tuyến tính")
        plt.plot(future_dates, y_pred_tree, color="green", marker="s", label="Dự báo - Cây quyết định")
        plt.xlabel("Thời gian")
        plt.ylabel("Doanh thu")
        plt.title("Dự báo doanh thu cho năm 2020")
        plt.xticks(rotation=45)
        plt.axhline(y=y.mean(), color='red', linestyle='--', label='Doanh thu trung bình 2019')
        plt.legend()
        plt.grid(True)

        # Lưu biểu đồ vào một dòng byte (mã hóa base64)
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_data = base64.b64encode(img.getvalue()).decode('utf-8')

        # Trả về kết quả dưới dạng phản hồi JSON
        return render_template("index.html", 
                               linear_results=linear_results, 
                               mae_linear=mae_linear, mse_linear=mse_linear, accuracy_linear=accuracy_linear,
                               tree_results=tree_results,
                               mae_tree=mae_tree, mse_tree=mse_tree, accuracy_tree=accuracy_tree,
                               better_model=better_model, plot_data=plot_data,
                               sales_usd=sales_usd, future_dates=future_dates)

    except Exception as e:
        return str(e), 400

if __name__ == '__main__':
    app.run(debug=True)
