import pandas as pd
import numpy as np
from flask import Flask, render_template, jsonify
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

def load_and_process_data(file_path):
    try:
        # Read the CSV file
        data = pd.read_csv(file_path, delimiter=";")
        data.columns = data.columns.str.strip()  # Clean column names
        data["Order_Date"] = pd.to_datetime(data["Order_Date"], dayfirst=True)
        
        # Calculate sales (Quantity * Price)
        data["Price_Each"] = data["Price_Each"].str.replace(",", "").astype(float)
        data["Sales"] = data["Quantity_Ordered"] * data["Price_Each"]
        
        # Monthly sales aggregation
        monthly_sales = data.set_index("Order_Date").resample("M")["Sales"].count().reset_index()
        return monthly_sales
    except Exception as e:
        raise ValueError(f"Error loading and processing data: {e}")

def run_model(model, X, y, future_days):
    model.fit(X, y)
    future_X = np.array(future_days).reshape(-1, 1)
    y_pred = model.predict(future_X)
    mae = mean_absolute_error(y, model.predict(X))
    mse = mean_squared_error(y, model.predict(X))
    return y_pred, round(mae, 2), round(mse, 2)

@app.route('/')
def index():
    try:
        data_path = "D:/DSS/Project/data.csv"
        monthly_sales = load_and_process_data(data_path)
        
        # Prepare data for training models
        X = np.array((monthly_sales["Order_Date"] - monthly_sales["Order_Date"].min()).dt.days).reshape(-1, 1)
        y = monthly_sales["Sales"].values
        
        # Future prediction dates
        future_dates = pd.date_range(start="2020-01-01", periods=12, freq='M')
        future_days = [(date - monthly_sales["Order_Date"].min()).days for date in future_dates]
        
        # Linear Regression Model
        linear_model = LinearRegression()
        y_pred_linear, mae_linear, mse_linear = run_model(linear_model, X, y, future_days)
        
        # Decision Tree Model
        tree_model = DecisionTreeRegressor(random_state=42)
        y_pred_tree, mae_tree, mse_tree = run_model(tree_model, X, y, future_days)

        # Calculate accuracy
        mean_actual = y.mean()
        accuracy_linear = round((1 - mae_linear / mean_actual) * 100, 2)
        accuracy_tree = round((1 - mae_tree / mean_actual) * 100, 2)

        # Determine the better model
        better_model = "Linear Regression" if mae_linear < mae_tree and mse_linear < mse_tree else "Decision Tree" if mae_tree < mae_linear and mse_tree < mse_linear else "Both models perform similarly"
        
        # Format the predicted sales values (rounded and with "USD" unit)
        y_pred_linear_usd = [f"${round(pred, 2):,.2f}" for pred in y_pred_linear]
        y_pred_tree_usd = [f"${round(pred, 2):,.2f}" for pred in y_pred_tree]

        # Format the actual sales data with month label
        sales_usd = [f"Tháng {i+1}: ${round(sale, 2):,.2f} USD" for i, sale in enumerate(monthly_sales["Sales"])]

        # Plot the results
        plt.figure(figsize=(14, 7))
        plt.plot(monthly_sales["Order_Date"], y, marker='o', color="black", label="Actual Sales 2019", linewidth=2)
        plt.plot(future_dates, y_pred_linear, color="blue", marker="x", label="Predictions - Linear Regression")
        plt.plot(future_dates, y_pred_tree, color="green", marker="s", label="Predictions - Decision Tree")
        plt.xlabel("Time")
        plt.ylabel("Sales")
        plt.title("Sales Forecast for 2020")
        plt.xticks(rotation=45)
        plt.axhline(y=y.mean(), color='red', linestyle='--', label='Average Sales 2019')
        plt.legend()
        plt.grid(True)

        # Save the plot to a byte stream (base64 encoding)
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_data = base64.b64encode(img.getvalue()).decode('utf-8')

        # Return results as JSON response
        return render_template("index.html", 
                               linear_results=y_pred_linear_usd, 
                               mae_linear=mae_linear, mse_linear=mse_linear, accuracy_linear=accuracy_linear,
                               tree_results=y_pred_tree_usd,
                               mae_tree=mae_tree, mse_tree=mse_tree, accuracy_tree=accuracy_tree,
                               better_model=better_model, plot_data=plot_data,
                               sales_usd=sales_usd, future_dates=future_dates)

    except Exception as e:
        return str(e), 400

if __name__ == '__main__':
    app.run(debug=True)
