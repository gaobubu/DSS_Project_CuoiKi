# Sales Prediction App

This is a web application built using Flask, which predicts sales for the year 2020 using two models:
- **Linear Regression**
- **Decision Tree Regressor**

The predictions are based on historical sales data. The app displays the predictions and model evaluation metrics (MAE, MSE, Accuracy) for each model and compares them to show which model performs better.

## Requirements

To run the application, you will need to install the following dependencies:

1. **Flask**: Web framework used to build the app.
2. **Pandas**: Used for handling and processing data.
3. **NumPy**: Used for numerical operations.
4. **Scikit-learn**: Machine learning library for building the models.
5. **Matplotlib**: Used to generate plots of the predictions.

You can install all the required dependencies by running:

```bash
pip install -r requirements.txt
